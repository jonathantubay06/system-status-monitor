# System Status Monitor — Airtable Edition

## Your Credentials (already set up!)
- **Airtable Base ID:** `appaNpdUbZxM8ChBW`
- **Airtable Token:** stored securely as GitHub/Netlify secret

---

## Setup Steps

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/system-status-monitor.git
git push -u origin main
```

### 2. GitHub Secrets
Go to your repo → **Settings → Secrets and variables → Actions** → add:

| Secret | Value |
|---|---|
| `AIRTABLE_BASE_ID` | `appaNpdUbZxM8ChBW` |
| `AIRTABLE_TOKEN` | `pat2kVZX6IVZZXC1a.7a2fc2eb57df266ca3e5bfd45a6d7c4e8a4930d61e498e7508e6e52362d8ff3a` |
| `ADMIN_PASSWORD` | Choose a strong password for the dashboard admin panel |
| `SLACK_WEBHOOK_URL` | Optional — Slack alerts |
| `SENDGRID_API_KEY` | Optional — email alerts |
| `ALERT_FROM_EMAIL` | Optional — sender email |

### 3. Netlify
1. Connect your GitHub repo to Netlify
2. `netlify.toml` handles build config automatically — no extra settings needed
3. Add these **Environment Variables** in Netlify (Site settings → Environment variables):
   - `AIRTABLE_BASE_ID` → `appaNpdUbZxM8ChBW`
   - `AIRTABLE_TOKEN` → your token
   - `ADMIN_PASSWORD` → same password as GitHub secret

### 4. Enable GitHub Actions
Go to the **Actions** tab in your repo → enable workflows.

---

## Using the Dashboard

### Managing projects
1. Click **⚙ Manage** top right
2. Enter your admin password
3. Add/edit/remove projects — changes sync to Airtable immediately
4. Monitor picks up changes on the next scheduled run (within 15 min)

### Adding a Softr project
- Type: `softr`
- URL: paste the full magic link
- The monitor will use Playwright to log in and verify the portal loads

### Adding a Shopify project
- Type: `shopify`  
- URL: your storefront URL (e.g. `https://yourstore.myshopify.com`)
- Simple HTTP check — no login needed

---

## Local Testing
```bash
npm install
npx playwright install chromium
AIRTABLE_BASE_ID="appaNpdUbZxM8ChBW" AIRTABLE_TOKEN="your_token" node scripts/monitor.js
```
